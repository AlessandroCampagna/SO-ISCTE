#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº: 105088      Nome: Alessandro Costa Campagna
## Nome do Módulo: altera_taxa_portagem.sh
## Descrição/Explicação do Módulo: 
##
##
###############################################################################
if [ $# -lt 3 ]; then   #checka se os argumentos sao pelo menos 3 se não for dá erro e sai
    ./error 2 && exit
elif [[ ! $1 =~ ^.*-.*$ ]]; then  #checka se o primeiro argumento é tem o formato (string-string) se não tiver da erro e sai
    ./error 3 "$1" && exit
elif [[ ! $2 =~ ^[A-Z][0-9]+$ ]]; then #checka se o segundo argumento tem o formato LeteraNumero se não tiver da erro e sai
    ./error 3 "$2" && exit
elif [[ ! $3 =~ ^[0-9][0-9]*$ ]] || [ $3 -le "0" ]; then  #checka se o terceiro argumento e um numero natural positivo ou nulo se não for da erro e sai
    ./error 3 "$3" && exit
else 
    if [ ! -f portagens.txt ]; then #checka se o ficheiro exite se não exitir cria o ficheiro portagens.txt
        touch portagens.txt
    fi

    if ! grep -q $1 portagens.txt; then                                #checka se o primeiro argumento exite em portagens.txt
        idp=` cat portagens.txt | cut -d ':' -f1 | sort -n | tail -1 ` #se nao existir adiciona o coma informaçao dada pelo utiliador
        idp=$(($idp+"1"))                                              #se exitir apenas muda o valor da taxa
        echo -e "$idp:$1:$2:$3" >> portagens.txt
    else
        line=`grep -n ":$1:" portagens.txt | cut -d ':' -f1`
        sed -i "${line}s/:[0-9][0-9]*/:$3/" portagens.txt
    fi 
    ./success 3 $1
fi
./success 4 portagens.txt | sort -t : -k 3,3 -k 2,2  #Mostra a informação de portagens.txt ordenada primeiro pelas auto-estradas e secundariamente pelo Lança (alphabeticamente)
