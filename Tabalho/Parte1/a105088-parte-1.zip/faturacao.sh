#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº:105088      Nome:Alessandro Costa Campagna 
## Nome do Módulo: faturacao.sh
## Descrição/Explicação do Módulo: 
##
##
###############################################################################
if [ ! -f relatorio_utilizacao.txt ]; then       #checka se relatorio_utilização.txt exite
    ./error 1 relatorio_utilizacao.txt && exit   #se nao exitir da erro e sai
fi

if [ -f faturas.txt ]; then #checka se ja exite um ficheiro faturas.txt
    rm faturas.txt          #se exitir apaga-o 
fi

if [ -s relatorio_utilizacao.txt ];then

#checka se exite conteudo em relatorio_utilizacao.txt
#se exitir cria um ficheiro faturas.txt com a informação de fatura de cada pessoa

    touch faturas.txt
    n=`cat pessoas.txt | wc -l` # numero de pessoas
    x=1 #variavel para varrer o ficheiro pessoas.txt

    while [ $x -le $n ]; do  
        nome=`cat pessoas.txt | cut -d ':' -f2 | tail -n +${x} | head -1 ` #recolhe o nome da pessoa na linha x do pessoas.txt
        echo "Cliente: $nome" >> faturas.txt                               #adiciona o nome da pessoa na linha x de pessoas.txt a faturas.txt
        id=`cat pessoas.txt | cut -d ':' -f3 | tail -n +${x} | head -1 `   #recolhe o id da pessoa na linha x de pessoas.txt
        cat relatorio_utilizacao.txt | grep "ID$id" >> faturas.txt         #adiciona a informaça dessa pessoa presente em relatorio_utilização.txt a faturas.txt
        
        m=`cat relatorio_utilizacao.txt | grep "ID$id" | wc -l `           #numero de linhas em relatorio_utilizacao.txt
        y=1                                                                #variavel para varrer o ficheiro relatorio_utilizacao.txt
        t=0                                                                #variavel para somar o total de creditos da pessoa
        while [ $y -le $m ]; do
            c=`cat relatorio_utilizacao.txt | grep "ID$id" | tail -n +$y | head -1 | cut -d ':' -f5 ` #credito da portagem da linha y
            t=$(($t + $c))                                                 #soma desse credito ao total somado
            y=$(($y+1))                                                    #y passa a proxima linha
        done

        echo "Total: $t créditos" >> faturas.txt                           #adiciona a fatura o total de credito da pessoa da linha x a faturas.txt
        x=$(($x+1))                                                        #x passa para proxima pessoa
    done
fi
./success 5 "faturas.txt" #mostra o ficheiro faturas.txt criado
exit