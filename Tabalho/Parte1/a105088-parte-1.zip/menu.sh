#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº:105088       Nome:Alessandro Costa Campagna
## Nome do Módulo: menu.sh
## Descrição/Explicação do Módulo: 
##
##
###############################################################################~
#menu do scripts feitos antes
while [[ $op != "0" ]]; do      #enquanto o input nao for 0 o utilizador mantem se no menu

    echo
    echo "1. Listar condutores"
    echo "2. Altera taxa de portagem"
    echo "3. Stats"
    echo "4. Faturação"
    echo "0. Sair"
    echo
    echo -e -n "Opção: "
    read op
    

    if [[ ! $op =~ ^[0-9][0-9]*$ ]] || [ $op -lt "0" ] || [ $op -gt "4" ]; then  # checka se o input tem o formato correto
        ./error 3 $op
    elif [ $op = "1" ]; then #executa lista_condutores.sh caso o input seje 1
        echo
        ./lista_condutores.sh
    elif [ $op = "2" ]; then  #lança um segundo menu para a insersão dos argumentos necessario e depois executa altera_taxa_portagem.sh
        echo
        echo "Altera taxa de portagem..."
        echo
        echo -e -n "Lanço           : "
        read l
        echo -e -n "Auto-estrada    : "
        read a
        echo -e -n "Novo valor taxa : "
        read t
        echo
        ./altera_taxa_portagem.sh $l $a $t
    elif [ $op = "3" ]; then #lança um segundo menu para decidir a função que stats.sh vai executar
        echo
        echo "Stats"
        echo
        echo "1. Nome de todas as Autoestradas"
        echo "2. Registos de utilização"
        echo "3. Listagem condutores"
        echo "0. Voltar"
        echo
        echo -e -n "Opção: "
        read op1
        if [ $op1 = "2" ]; then                  #funciona como o menu principal para as opçoes de stats.sh
            echo -e -n "Minimo de registos: "
            read mr
            echo
            ./stats.sh "registos" "$mr"
        elif [ $op1 = "1" ]; then
            echo
            ./stats.sh "listar" 
        elif [ $op1 = "3" ]; then
            stats="condutores"
            echo
            ./stats.sh "condutores" 
        elif [ $op1 = "0" ];then
            :
        fi
            
    elif [ $op = "4" ]; then #executa faturacao.sh caso o input seje 4
        echo
        ./faturacao.sh
    fi

done