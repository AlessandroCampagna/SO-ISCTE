#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº:105088       Nome:Alessandro Costa Campagna
## Nome do Módulo: stats.sh
## Descrição/Explicação do Módulo: 
##
##
###############################################################################
if [ $# -lt "1" ]; then                                                            #checka se ha pelo menu 1 argumento se não dá erro

    ./error 2 && exit

elif [[ $1 =~ ^"listar"$ ]]; then                                                  #checka qual a opçao escolhaida caso nao seja (listar,registos ou condutores) dá erro
    if [ $# -ge "1" ]; then                                                        #volta a checkar se ha o numero de argumentos necessario
        cat "portagens.txt" | cut -d ':' -f3 | sort | uniq |  ./success 6          #mostra as auto-estradas em portagens.txt
    else 
        ./error 2 && exit 
    fi


elif [[ $1 =~ ^"registos"$ ]]; then
    if [ $# -ge "2" ]; then #checka se tem o arguntos necessario para esta funçao
        if [[ $2 =~ ^[0-9][0-9]*$ ]] && [ $2 -gt "0" ]; then                        #checka se os <rgumentos têm o formato correto
            r=`cat portagens.txt | wc -l`                                           #numero de portagens ou lanços
            x=1                                                                     #variavel para varrer portagens.txt
            while  [ $x -le $r ]; do
                registo=`cat portagens.txt | tail -n +$x | head -1 | cut -d ':' -f2 ` #mostra o lança da linha x
                n=`cat relatorio_utilizacao.txt | grep "$registo" | wc -l`            #checka a quantodade de vezes que este laanço se repete em relatorio_utilizacao.txt
                if [ $n -ge $2 ]; then                                              #se a quantidade for maior ou igual á inserida pelo utilizador
                    s=`cat portagens.txt | grep "$registo" | cut -d ':' -f2`        #adiciona esse lanço ao output
                    if [ $x -gt "1" ]; then
                        stats="${stats}\|$s"
                    else
                        stats="$s"
                    fi
                fi
                x=$(($x+1))                                                       #proxima linha 
            done
            cat portagens.txt | cut -d ':' -f2 | grep "$stats" | ./success 6      #mostra os lanços que se repetem mais ou igual ao nume de vezes inserido pelo utilizador
        else
            ./error 3 $2 && exit
        fi
    else
        ./error 2 && exit
    fi


elif [[ $1 =~ ^"condutores"$ ]]; then
    p=`cat pessoas.txt | wc -l`            #numero de linhas de pessoas.txt
    x=1                                    #variavel para varrer pessoas.txt
    while [ $x -le $p ]; do                                  
        id=`cat pessoas.txt | cut -d ':' -f3 | tail -n +$x | head -1`  #id da pessoa x
        if grep -q "ID$id" relatorio_utilizacao.txt; then               #se essa pessoa estiver em relatorio_utilizacao.txt
            if [ $x -gt "1" ]; then                                     #adiciona-a ao output
                condutores="${condutores}\|$id"
            else
                condutores="$id"
            fi
        fi
        x=$(($x+1))
    done
    cat pessoas.txt | grep "$condutores" | cut -d ':' -f2 | ./success 6   #mostra as pessoas que aparecem em relatorio_utilizacao.txt

else

    ./error 3 $1

fi
